from dataclasses import dataclass
import math

import numpy as np
from scipy.signal import butter, istft, sosfilt, stft


class ButterworthHighPassFilter:
    """Removes electrical hum (50/60 Hz) and low-frequency rumble."""

    def __init__(self, cutoff_hz: float = 180.0, sample_rate: int = 16000, order: int = 5):
        self.cutoff_hz = cutoff_hz
        self.sample_rate = sample_rate
        self.order = order
        # Ensure cutoff is below Nyquist
        nyquist = sample_rate / 2.0
        cutoff = min(cutoff_hz, nyquist - 10.0)
        self.sos = butter(order, cutoff, "hp", fs=sample_rate, output="sos")

    def __call__(self, audio: np.ndarray) -> np.ndarray:
        if len(audio) < 16:
            return audio.astype(np.float32)
        filtered = sosfilt(self.sos, audio)
        return filtered.astype(np.float32)


def normalize_audio(audio: np.ndarray, target_peak: float = 0.85) -> np.ndarray:
    """Normalizes clean speech to avoid clipping while ensuring optimal signal level."""
    if len(audio) == 0:
        return audio.astype(np.float32)
    peak = float(np.percentile(np.abs(audio), 99.8))
    if peak > 1e-4:
        scaled = audio * (target_peak / peak)
        return np.clip(scaled, -0.98, 0.98).astype(np.float32)
    return audio.astype(np.float32)


class NlmsEchoCanceller:
    def __init__(self, filter_length: int = 1024, step_size: float = 0.2):
        self.filter_length = filter_length
        self.step_size = step_size
        self.weights = np.zeros(filter_length, dtype=np.float64)
        self.history = np.zeros(filter_length, dtype=np.float64)

    def __call__(self, microphone: np.ndarray, playback_reference: np.ndarray) -> np.ndarray:
        if len(microphone) != len(playback_reference):
            raise ValueError("microphone and playback reference must have equal lengths")
        output = np.empty(len(microphone), dtype=np.float32)
        for index, (sample, reference) in enumerate(
            zip(microphone, playback_reference, strict=True)
        ):
            self.history[1:] = self.history[:-1]
            self.history[0] = reference
            estimate = float(self.weights @ self.history)
            error = float(sample - estimate)
            power = float(self.history @ self.history) + 1e-8
            self.weights += self.step_size * error * self.history / power
            output[index] = error
        return output


class SpectralDenoiser:
    def __init__(self, sample_rate: int, strength: float = 0.75, noise_seconds: float = 0.25):
        self.sample_rate = sample_rate
        self.strength = strength
        self.noise_seconds = noise_seconds

    def __call__(self, audio: np.ndarray) -> np.ndarray:
        if len(audio) < 2:
            return audio.astype(np.float32)
        nperseg = min(512, len(audio))
        _, _, spectrum = stft(audio, fs=self.sample_rate, nperseg=nperseg)
        noise_frames = max(1, int(self.noise_seconds * self.sample_rate / (nperseg // 2)))
        noise = np.median(np.abs(spectrum[:, :noise_frames]), axis=1, keepdims=True)
        magnitude = np.abs(spectrum)
        gain = np.maximum(1.0 - self.strength * noise / np.maximum(magnitude, 1e-8), 0.08)
        _, clean = istft(spectrum * gain, fs=self.sample_rate, nperseg=nperseg)
        return clean[: len(audio)].astype(np.float32)


@dataclass(frozen=True)
class SpeechSegment:
    start_sample: int
    end_sample: int
    audio: np.ndarray


class EnergyVad:
    def __init__(
        self,
        sample_rate: int,
        frame_ms: int = 30,
        threshold_db: float = 8.0,
        minimum_speech_ms: int = 240,
        release_ms: int = 300,
    ):
        self.sample_rate = sample_rate
        self.frame_samples = sample_rate * frame_ms // 1000
        self.threshold_db = threshold_db
        self.minimum_frames = max(1, minimum_speech_ms // frame_ms)
        self.release_frames = max(1, release_ms // frame_ms)

    def split(self, audio: np.ndarray) -> list[SpeechSegment]:
        frame_count = len(audio) // self.frame_samples
        if frame_count == 0:
            return []
        frames = audio[: frame_count * self.frame_samples].reshape(frame_count, self.frame_samples)
        levels = 20 * np.log10(np.sqrt(np.mean(frames**2, axis=1)) + 1e-8)
        noise_floor = float(np.percentile(levels, 20))
        active = levels >= noise_floor + self.threshold_db
        segments: list[SpeechSegment] = []
        start = None
        silence = 0
        for index, is_active in enumerate(active):
            if is_active:
                start = index if start is None else start
                silence = 0
            elif start is not None:
                silence += 1
                if silence >= self.release_frames:
                    self._append(segments, audio, start, index - silence + 1)
                    start = None
                    silence = 0
        if start is not None:
            self._append(segments, audio, start, frame_count)
        return segments

    def _append(
        self, segments: list[SpeechSegment], audio: np.ndarray, start_frame: int, end_frame: int
    ) -> None:
        if end_frame - start_frame < self.minimum_frames:
            return
        start = start_frame * self.frame_samples
        end = min(len(audio), (end_frame + self.release_frames) * self.frame_samples)
        segments.append(SpeechSegment(start, end, audio[start:end]))
